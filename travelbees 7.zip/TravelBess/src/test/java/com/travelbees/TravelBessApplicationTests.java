package com.travelbees;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelBessApplicationTests {

	@Test
	void contextLoads() {
	}

}
