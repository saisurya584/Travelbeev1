package com.travelbees.entity;

public enum Role {

	USER,
	ADMIN
}
