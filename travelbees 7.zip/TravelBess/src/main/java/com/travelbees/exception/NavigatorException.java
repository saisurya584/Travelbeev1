package com.travelbees.exception;

public class NavigatorException extends RuntimeException {
    public NavigatorException(String message) {
        super(message);
    }


}
