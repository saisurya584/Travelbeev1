package com.cg.constants;


	public class TouristConstants {
		 public static final String SOMETHING_WENT_WRONG = "Something went wrong";
		 public static final String INVALID_DATA = "Invalid data";
		 public static final String UNATHORIZED_ACCESS = "Unathorizhed access.";

	}



